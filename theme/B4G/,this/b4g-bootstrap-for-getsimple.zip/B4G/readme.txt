1. Requirements: 
	- Plugins: I18N
2. Create 9 components:
box1, box2, box3
carousel1, carousel2, carousel3
footer_left, footer_middle, footer_right

	- Go to THEME card (in Administration interface)
	- Select EDIT COMPONENTS
	- Click to ADD COMPONENT button and add these 9 components.
	
Go to http://getbootstrap.com/customize/ if you want change the color scheme of this theme.